from flask import Flask, request, render_template, redirect, url_for
import cv2
import numpy as np
from io import BytesIO
from PIL import Image
import os

app = Flask(__name__)

# Function to process the image
def process_image(image):
    laplacian = cv2.Laplacian(image, cv2.CV_64F)
    laplacian = np.uint8(np.absolute(laplacian))
    sharpened_image = cv2.subtract(image, laplacian)
    sobel_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)
    sobel_combined = np.sqrt(sobel_x**2 + sobel_y**2)
    sobel_combined = np.uint8(np.absolute(sobel_combined))
    smoothed_image = cv2.blur(sobel_combined, (5, 5))
    smoothed_image_normalized = smoothed_image / 255.0
    sharpened_image_normalized = sharpened_image / 255.0
    result_normalized = smoothed_image_normalized * sharpened_image_normalized
    result_image = np.uint8(result_normalized * 255)
    final_image = cv2.add(result_image, image)
    gamma = 0.5
    gamma_corrected = np.array(255 * (final_image / 255) ** gamma, dtype='uint8')
    return laplacian, sharpened_image, sobel_combined, smoothed_image, result_image, final_image, gamma_corrected

@app.route('/')
def index():
    background_url = "https://example.com/path/to/your/background.jpg"
    return render_template('index.html', background_url=background_url)

@app.route('/upload', methods=['GET', 'POST'])
def upload_image():
    background_url = "https://example.com/path/to/your/background.jpg"
    if request.method == 'POST':
        file = request.files['file']
        if file:
            img = Image.open(file.stream).convert('L')
            image = np.array(img)
            laplacian, sharpened_image, sobel_combined, smoothed_image, result_image, final_image, gamma_corrected = process_image(image)
            processed_images = {'original': image, 'gamma_corrected': gamma_corrected}
            for key, img in processed_images.items():
                img_pil = Image.fromarray(img)
                img_pil.save(f'static/{key}.png')
            return render_template('display.html', background_url=background_url)
    return render_template('upload.html', background_url=background_url)

if __name__ == '__main__':
    app.run(debug=True)
